Build command

gradle clean
gradle assembleDebug

The APK File is located in

app/build/outputs/apk/debug


